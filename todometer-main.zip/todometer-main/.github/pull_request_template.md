## What this does (in your own words)

## What this does (according to GitHub Copilot)

copilot:summary

copilot:walkthrough

## Relevant issue

## A poem

copilot:poem

